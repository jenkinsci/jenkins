package io.jenkins.plugins.example;

import hudson.tools.JDKInstaller;

public class Caller {

    public static JDKInstaller use() {
        return new JDKInstaller(null, false);
    }

    private Caller() {}

}
