package test;

import junit.framework.TestCase;

public class ITTest extends TestCase {

    public void test() {
        
    }
}
