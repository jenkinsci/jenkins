package test;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
	This will not compile.
        System.out.println( "Hello World!" );
    }
}
