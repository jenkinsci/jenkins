package org.jvnet.hudson.test;

public class JustAClass {
}
