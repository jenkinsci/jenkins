System.setProperty("started", "true");
Nonexistent.run();
