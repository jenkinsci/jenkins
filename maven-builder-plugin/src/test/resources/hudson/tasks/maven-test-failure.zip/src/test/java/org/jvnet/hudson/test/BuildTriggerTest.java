package org.jvnet.hudson.test;

import junit.framework.TestCase;

public class BuildTriggerTest extends TestCase {
    public void testSomething() {
        fail("test failure");
    }
}
